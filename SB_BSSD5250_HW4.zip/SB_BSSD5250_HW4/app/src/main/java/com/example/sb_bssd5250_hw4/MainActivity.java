package com.example.sb_bssd5250_hw4;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.TypedValue;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);

        String[] words = {"Tables", "Chairs.", "Recalcitrant.", "~Churlish", "Div"};
        int[] colors = {Color.RED, Color.GREEN, Color.BLACK, Color.TRANSPARENT, Color.YELLOW};

        TableLayout tableLayout = new TableLayout( this);
        tableLayout.setBackgroundColor(Color.GREEN);
        TableLayout.LayoutParams  tlParams = new TableLayout.LayoutParams(
                TableLayout.LayoutParams.WRAP_CONTENT,
                TableLayout.LayoutParams.WRAP_CONTENT);
        tableLayout.setLayoutParams(tlParams);

        TextView tv = makeTV( "Tables!", Color.RED);
        TextView tv2 = makeTV( "Chairs.", 0);

        TableRow tr = makeTr(Color.BLUE);


        tr.addView(tv);
        tr.addView(tv2);
        tableLayout.addView(tr);

        setContentView(tableLayout);
    }

    private TextView makeTV(String content, int color) {
        TextView textView = new TextView( this);
        textView.setText(content);
        textView.setTextColor(Color.WHITE);
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 39);
        textView.setBackgroundColor(color);

        return textView;
    }

    private TableRow makeTr(int color) {
        TableRow tableRow = new TableRow(this);
        tableRow.setBackgroundColor(color);
        TableRow.LayoutParams trParams = new TableRow.LayoutParams(
                TableRow.LayoutParams.WRAP_CONTENT,
                TableRow.LayoutParams.WRAP_CONTENT);
        tableRow.setLayoutParams(trParams);
        return tableRow;


    }


}
