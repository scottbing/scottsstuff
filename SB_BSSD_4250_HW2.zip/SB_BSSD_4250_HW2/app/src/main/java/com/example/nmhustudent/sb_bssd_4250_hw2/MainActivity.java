package com.example.nmhustudent.sb_bssd_4250_hw2;

import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.constraint.ConstraintSet;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);

        ConstraintLayout constraintLayout = new ConstraintLayout( this );

        TextView tedxtView = new TextView( this);
        textView.setText("Hello World");

        constraintLayout.addView(textView);
        constraintLayout.LayoutParams clParams =
                new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.MATCH_PARENT,
                        ConstraintLayout.LayoutParams.MATCH_PARENT);
        ConstraintLayout.setBackgroundColor(0xFF00FF00);
        constraintLayout.setID(View.generateViewId());

        TextView textView = new TextView(this);
        ConstraintLayout.setBackgroundColor(0xFFFFFFFF);
        constraintLayout.setID(View.generateViewId());
        textView.setText("Hello World");

        int tid = textView.getId();
        int pid = ConstraintSet.PARENT_ID;
        ConstraintSet centerSet = new ConstraintSet();centerSet.constraintHeight(tid, ConstraintSet.WRAP_CONTENT);
        centerSet.constraintHeight(tid, ConstraintSet.WRAP_CONTENT);
        centerSet.constraintHeight(tid, ConstraintSet.WRAP_CONTENT);


        cneterSet.connect(tid, ConstraintSet.BOTTOM, pid ConstraintSet.BOTTOM, margin 0);
        centerSet.applyto(constraintLayout);
        Button blueButton = new Button( context this);
        blueButton.setText("Click Me");
        blueButton.setBackgroundColor.BLUE);;

        constraintLayout.Addview(blueButton);





        constraintLayout.addView(textView);
        setContentView(constraintLayout);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
