            num=prompt("Enter the letter 'a', 'b' or 'c'");
            
            if  (num=="a") {
                confirm("you entered 'a'")
            } else if (num=="b") {
                confirm("You entered 'b'")
            } else if (num=="c")  {
                confirm("You entered 'c'")
            } else {
                confirm("You did not follow directions.");
            }
            
            var choice = prompt("Choose A, B, or C");
            if (choice.toLowerCase() == 'a') {
                document.write("I chose A");
            } else if (choice.toLowerCase() == 'b') {
                document.write("I chose B");
            } else if (choice.toLowerCase() == 'c') {
                document.write("I chose c");
            } else {
                confirm("you didn't  choose A, B, or C")
            }           